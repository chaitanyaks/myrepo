import boto3,json,time,botocore,yaml
#import testconfig.yaml
instances_count = input("Enter the count to launch the instances :")
class AWS_EC2():
    def connect(self):
        
        self.ec2 = boto3.resource("ec2")
        self.client = boto3.client("ec2")

    def yaml_loader(self,filepath):
        with open(filepath,"r")as file_descriptor:
            self.data=yaml.load(file_descriptor)
            print self.data
        return self.data

    def linux_userdata(self):
        userdata = """#!/usr/bin/env python3
import os,sys,time
os.chdir("/home/ec2-user/")
time.sleep(10)
os.system("sudo wget -O ./installer_linux.py https://console.cloudendure.com/installer_linux.py")
time.sleep(30)
os.system("sudo python ./installer_linux.py -t BB33-F928-42EC-8F77-0AF9-3A5E-1E18-95BA-E4D5-B466-EAB1-772F-48B9-AEFE-C8C0-F6BE --no-prompt")
time.sleep(20)
"""
        time.sleep(5)
        return userdata

    def EC2Ins(self,image_id,instancetype,Keypair,sg,subnet,tagkey=None,tagvalue=None,role=None,userdata=None):
        
        
        instance= self.ec2.create_instances(ImageId = image_id,
                                            #SecurityGroups = [self.securitygroup1['SG_name']],
                                            SecurityGroupIds = [sg],
                                            SubnetId = subnet,
                                            InstanceType = instancetype,
                                            MinCount = 1,
                                            MaxCount = 1,
                                            KeyName = Keypair,
                                            UserData = linux_userdata,
##                                            IamInstanceProfile={
##                                                'Name': role
##                                                },
                                            TagSpecifications=[{
                                                'ResourceType': 'instance',
                                                'Tags':[{
                                                    'Key': tagkey,
                                                    'Value': tagvalue
                                                    }
                                                ]
                                                }]
                                            )
        time.sleep(20)
        instance_id=instance[0].id
        response = self.client.describe_tags(
            Filters=[{
                'Name': 'resource-id',
                'Values': [instance_id,],
                },
            ],
            )
        key= response['Tags'][0]['Key']
        value= response['Tags'][0]['Value']
        return key, value

A=AWS_EC2()
A.connect()
linux_userdata = A.linux_userdata()
print "userdata: ", linux_userdata
filepath="testconfig.yaml"
##data= A.yaml_loader(filepath)
##for i in range(instances_count):
##    if i <= instances_count:
##        key,value = A.EC2Ins(image_id = data['os'],instancetype = data['instancetype'],Keypair = data['keypair'],sg = data['securitygroup'],subnet = data['subnet'],tagkey = 'Name',tagvalue = 'test-Demo',role=None,userdata=None)
##
##print key,value
