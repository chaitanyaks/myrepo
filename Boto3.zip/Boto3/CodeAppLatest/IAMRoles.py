import boto3,json,time
from botocore.exceptions import ClientError
iam=boto3.client('iam')

RoleNameEC2=raw_input("Enter the role name to create for EC2: ")
PolicyNameEC2= raw_input("Enter the policy name to create for EC2: ")
InstanceProfileRoleEC2=raw_input("Enter the instance profile role to create for EC2: ")

RoleNameCD= raw_input("Enter the role name to create for codedeploy: ")
PolicyNameCD= raw_input("Enter the policy name to create for codedeploy: ")

def EC2Role():
    
    """
    IAM Instance Profile role creation for EC2 Instances
    """
    
    try:
            
        AssumeRolePolicy= { 'Version' : '2012-10-17','Statement':[{"Effect": "Allow","Principal": { "Service": "ec2.amazonaws.com"},"Action": "sts:AssumeRole"}]}
        AssumeRole_json=json.dumps(AssumeRolePolicy,indent=2)


        role = iam.create_role(RoleName= RoleNameEC2,AssumeRolePolicyDocument= AssumeRole_json ,Description='Instance Profile role for EC2')

    except ClientError as a:
        if a.response['Error']['Code'] == 'EntityAlreadyExists':
            print "Role already exists.Please specify another role name to create for EC2"
            raise
                
        else:
            print "Unexpected error while creating role for EC2: %s" %a

    try:

        # IAM Instance profile policy creation and attaching the policy to the role.

        policy= {'Version': '2012-10-17','Statement': [{"Action": ["ec2:*","codedeploy:*","autoscaling:Describe*","s3:Get*","s3:List*"],"Effect": "Allow","Resource": "*"}]}
        policy_json=json.dumps(policy,indent=2)

        InstanceRolePolicy=iam.create_policy(PolicyName= PolicyNameEC2,PolicyDocument= policy_json,Description='Instance role policy')
        Attachpolicy=iam.attach_role_policy(RoleName=role['Role']['RoleName'],PolicyArn=InstanceRolePolicy['Policy']['Arn'])
        time.sleep(10)

    except ClientError as b:
        if b.response['Error']['Code'] == 'EntityAlreadyExists':
            print "Policy already exists.Please specify another role name to create for EC2"
            raise
        else:
            print "Unexpected error while creating policy for EC2: %s" %b 
    try:    
        InstanceRoleInstanceProfile= iam.create_instance_profile(InstanceProfileName=InstanceProfileRoleEC2)
        AttachInstancepolicy= iam.add_role_to_instance_profile(InstanceProfileName=InstanceRoleInstanceProfile['InstanceProfile']['InstanceProfileName'],RoleName=role['Role']['RoleName'])
        time.sleep(20)
        response= InstanceRoleInstanceProfile['InstanceProfile']['InstanceProfileName']

    except ClientError as c:
        if c.response['Error']['Code'] == 'EntityAlreadyExists':
            print "Instance Policy already exists.Please specify another role name to create for EC2"
            raise
        else:
            print "Unexpected error while creating instance policy for EC2: %s" %c
                
    return response
        

def CDRole(args):
    """
    Service role creation for codedeploy
    """
    try:
        AssumeRolePolicyCD= {'Version' : '2012-10-17','Statement':[{"Sid": "1","Effect": "Allow","Principal": {"Service": ["codedeploy.us-west-2.amazonaws.com"]},"Action": "sts:AssumeRole"}]}
        AssumeRoleCD_json=json.dumps(AssumeRolePolicyCD,indent=2)
        role_CD= iam.create_role(RoleName=args,AssumeRolePolicyDocument= AssumeRoleCD_json, Description='CodeDeploy Role')

    except ClientError as d:
        if d.response['Error']['Code'] == 'EntityAlreadyExists':
            print "Role already exists.Please specify another role name to create for CodeDeploy"
            raise
        else:
            print "Unexpected error while creating role for codedeploy: %s" %d

    try:
        policyCD= {'Version': '2012-10-17','Statement':[{"Effect": "Allow","Resource": ["*"],"Action": ["ec2:Describe*"]},{"Effect": "Allow","Resource": ["*"],"Action": ["autoscaling:*"]}]}
        policyCD_json=json.dumps(policyCD,indent=2)
        RolePolicyCD=iam.create_policy(PolicyName=PolicyNameCD,PolicyDocument= policyCD_json,Description= 'Policy for codedeploy')
        AttachCDPolicy= iam.attach_role_policy(RoleName= role_CD['Role']['RoleName'],PolicyArn= RolePolicyCD['Policy']['Arn'])
        time.sleep(20)
        response= role_CD['Role']['Arn']
    except ClientError as e:
        if e.response['Error']['Code'] == 'EntityAlreadyExists':
            print "Policy already exists.Please specify another role name to create for CodeDeploy"
            raise
        else:
            print "Unexpected error while creating policy for codedeploy: %s" %e
    return response

a=EC2Role()
b=CDRole()
print a,b

    
