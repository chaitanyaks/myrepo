if __name__ == "__main__":
    #rolename = "pythontestrole" 
    rolename = raw_input("enter the role name to create: ")
    #createrole(rolename)
