import test1

print test1.a
