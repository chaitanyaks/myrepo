import yaml

def yaml_loader(filepath):
    with open(filepath,"r")as file_descriptor:
        data=yaml.load(file_descriptor)
        print(data)
        #print(data['age'])



yaml_loader('test1yaml.yaml')


'''filepath="test12.yaml"
#filepath1="test2.yaml"
data= yaml_loader(filepath,'age')'''
