import boto3,json,time
from IAMRoles import EC2Role
import securitygroup,keypair,userdata

ec2 = boto3.resource('ec2')
iam = boto3.client('iam')
client=boto3.client('ec2')
#tagkey=raw_input("Enter the tag key for the EC2 Instance: ")
#tagvalue=raw_input("Enter the tag value for the EC2 Instance: ")
secgrp=raw_input("Enter the security group name: ")
keypairname=raw_input("Enter keypair name: ")
InstanceProfileRoles=raw_input("Enter the instance profile role: ")


def EC2Ins(*args):
   
    # Launching EC2 Instances

    instance=ec2.create_instances(ImageId='ami-efd0428f',
                              SecurityGroups=[secgrp],
                              SecurityGroupIds=[securitygroup.securitygroup(secgrp)],
                              InstanceType='t2.micro',
                              MinCount=1,
                              MaxCount=1,
                              KeyName= keypair.keypair(keypairname),
                              UserData= userdata.userdata('userdata'),
                              IamInstanceProfile={
                                  'Name': EC2Role(InstanceProfileRoles)
                                  
                                  },
                                  
                              
                              TagSpecifications=[{
                                  'ResourceType': 'instance',
                                  'Tags':[
                                      {
                                          'Key': args[0],
                                          'Value': args[1]
                                          }]
                                  }
                                  
                                      ]
                              )
    value=TagSpecifications[0].values()[1][0]['Value']
    key=TagSpecifications[0].values()[1][0]['Key']
    print value, key
    return key
EC2Ins('tagkey1','tagvalue1')

