import boto3,json,time
from DevEnv1 import EC2Ins
from IAMRoles import CDRole

def CD():
    appName=raw_input("Enter the Application Name for CodeDeploy: ")
    depgroup=raw_input("Enter the Deployment Group Name: ")

    codedeploy=boto3.client('codedeploy')
    iam=boto3.client('iam')


    # Codedeploy application

    application=codedeploy.create_application(applicationName=appName)

    # Codedeploy deployment group

    deploymentgroup=codedeploy.create_deployment_group(
        applicationName=appName,
        deploymentGroupName=depgroup,
        ec2TagFilters=[
            {
                'Key': EC2Ins('ca1','ca2'),
                #'Value': DevEnv1.EC2Ins(),
                'Type':'KEY_ONLY'
                },
            ],
        serviceRoleArn= CDRole('CDRole1')
        )
    time.sleep(50)
CD()
'''bucketloc=raw_input("Enter the Location of the bucket to run the revision: ")
revision= codedeploy.create_deployment(
    applicationName='appName',
    deploymentGroupName='depgroup',
    revision={
        rev=input("Choose the revision type, 1. S3 2. GitHub ")
        'revisionType': S3,
        's3Location':{
            'bucket': bucketloc,
            'bundleType': 'zip'
            }
        
            'gitHubLocation':{
                'repository':'string',
                'commitId': 'string'
                }
        },
    targetInstances={
        'tagFilters':[{
            'Key': 'tool2',
            'Value': 'tool2',
            'Type': 'KEY_AND_VALUE'
            }]
        })'''


